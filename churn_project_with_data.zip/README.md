# Churn Prediction Project

so this is my churn prediction project for ml class.  
i did the notebook in colab but put it here.  
not perfect but works. screenshots are in outputs folder.

## Steps I did (roughly)
1. imported libraries (pandas numpy etc)
2. loaded dataset (i used one from online)
3. did some preprocessing (label encoding + scaling)
4. train test split 80/20
5. logistic regression model trained
6. checked accuracy/confusion matrix/report

## Notes
- pls see the notebook for code.  
- accuracy was decent.  
- i might have missed some cleaning but okay.  
- outputs folder has screenshots i took while running.  

